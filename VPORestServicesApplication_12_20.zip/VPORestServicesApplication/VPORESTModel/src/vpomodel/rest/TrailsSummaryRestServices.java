package vpomodel.rest;

import java.util.HashMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import oracle.jbo.ApplicationModule;
import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import oracle.jbo.client.Configuration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import vpomodel.eo.AppModuleImpl;


@Path("trails")
@Consumes("application/json")
@Produces("application/json")
public class TrailsSummaryRestServices {

    private static final String amDef = "vpomodel.eo.AppModule";
    private static final String config = "AppModuleLocal";

    public TrailsSummaryRestServices() {
        super();
    }


    @GET
    @Path("/trailsSummary")
    public String getTrailsSummary(@QueryParam("personnelIdVal") String personnelId,
                                   @QueryParam("regionIdVal") String regionId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("TrialsSummaryVO2_1");
                vo.setNamedWhereClauseParam("trials2_personnelId", personnelId);
                vo.setNamedWhereClauseParam("trials2_regionalId", regionId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("trialCode", row.getAttribute("StudyCodeAlias").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("trialCode", "");
                        }
                        try {
                            jsonObjectR3.put("siteId", row.getAttribute("StudySiteId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("siteId", "");
                        }
                        try {
                            jsonObjectR3.put("primaryInvestigator", row.getAttribute("InvestigatorName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("primaryInvestigator", "");
                        }
                        try {
                            jsonObjectR3.put("pendingForms", row.getAttribute("PendingForms").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("pendingForms", "");
                        }
                        try {
                            jsonObjectR3.put("pendingShipment", row.getAttribute("PendingShipment").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("pendingShipment", "");
                        }
                        try {
                            jsonObjectR3.put("total", row.getAttribute("TotalAction").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("total", "");
                        }
                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("trialsSummary", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
            }

        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/trailsStudyCode")
    public String getTrailsStudyCode(@QueryParam("personnelIdVal") String personnelId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("TrailsStudyCode1");
                vo.setNamedWhereClauseParam("studyCode_personnelId", personnelId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("studyId", row.getAttribute("Studyid").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studyId", "");
                        }
                        try {
                            jsonObjectR3.put("studyCode", row.getAttribute("Studycode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studyCode", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("studyCodes", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
            }

        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/trailsSiteSummary")
    public String getTrailsSiteSummary(@QueryParam("personnelIdVal") String personnelId,
                                       @QueryParam("regionIdVal") String regionId,
                                       @QueryParam("studyCodeVal") String studyCode) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("TrailsSiteSummary1");
                vo.setNamedWhereClauseParam("site_personnelId", personnelId);
                vo.setNamedWhereClauseParam("site_regionId", regionId);
                vo.setNamedWhereClauseParam("site_studyCode", studyCode);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("siteId", row.getAttribute("StudySiteId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("siteId", "");
                        }
                        try {
                            jsonObjectR3.put("primaryInvestigator", row.getAttribute("InvestigatorName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("primaryInvestigator", "");
                        }
                        try {
                            jsonObjectR3.put("pendingForms", row.getAttribute("PendingForms").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("pendingForms", "");
                        }
                        try {
                            jsonObjectR3.put("pendingShipment", row.getAttribute("PendingShipment").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("pendingShipment", "");
                        }
                        try {
                            jsonObjectR3.put("total", row.getAttribute("TotalAction").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("total", "");
                        }
                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("trialsSiteSummary", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
            }

        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/trialsCounts")
    public String getTrialsHeaderDetails(@QueryParam("personnelIdVal") String personnelId,
                                         @QueryParam("studyCodeVal") String studyCode) {
        JSONObject jsonObjectR;
        HashMap<String, String> trialsCounts = new HashMap<String, String>();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);

            try {
                AppModuleImpl service = (AppModuleImpl) am;
                trialsCounts = service.callTrialsProcedure(personnelId, studyCode);
                //  trialsCounts.forEach((k, v) -> System.out.println(k + " : " + v));
                jsonObjectR = new JSONObject(trialsCounts);
                service.remove();
                Configuration.releaseRootApplicationModule(am, true);
            } catch (Exception e) {
                e.printStackTrace();
                jsonObjectR = new JSONObject();
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
            }

        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/trailsAlerts")
    public String getTrailsAlerts(@QueryParam("personnelIdVal") String personnelId,
                                  @QueryParam("studyCodeVal") String studyCode) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("TrialsAlerts1");
                vo.setNamedWhereClauseParam("trialsAlerts_personnelId", personnelId);
                vo.setNamedWhereClauseParam("trialsAlerts_studyCode", studyCode);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();

                        try {
                            jsonObjectR3.put("siteId", row.getAttribute("StudySiteId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("siteId", "");
                        }
                        try {
                            jsonObjectR3.put("category", row.getAttribute("AlertCategory").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("category", "");
                        }
                        try {
                            jsonObjectR3.put("title", row.getAttribute("AlertDetails").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("title", "");
                        }
                        try {
                            jsonObjectR3.put("date", row.getAttribute("CreatedDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("date", "");
                        }
                        try {
                            jsonObjectR3.put("readFlag", row.getAttribute("ReadFlag").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("readFlag", "");
                        }
                        try {
                            jsonObjectR3.put("archiveFlag", row.getAttribute("ArchiveFlag").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("archiveFlag", "");
                        }
                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("trialsAlerts", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
            }

        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/trialsAlertsCount")
    public String getTrialsAlertsUnreadCount(@QueryParam("personnelIdVal") String personnelId,
                                             @QueryParam("studyCodeVal") String studyCode) {
        JSONObject jsonObjectR = new JSONObject();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("TrialsAlertsUnreadCount1");
                vo.setNamedWhereClauseParam("trialsAlerts_personnelId", personnelId);
                vo.setNamedWhereClauseParam("trialsAlerts_studyCode", studyCode);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        try {
                            jsonObjectR.put(row.getAttribute("Unreadcount").toString(),
                                            row.getAttribute("Selectobjects1").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("UnreadCount", "");
                        }
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
            }

        } catch (Exception e) {
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }
}

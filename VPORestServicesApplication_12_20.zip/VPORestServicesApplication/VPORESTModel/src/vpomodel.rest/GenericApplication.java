package vpomodel.rest;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import oracle.wsm.metadata.annotation.PolicyReference;
import oracle.wsm.metadata.annotation.PolicySet;

import vpomodel.rest.CountryRestServices;
import vpomodel.rest.DashboardRestServices;
import vpomodel.rest.FormAutomationRestServices;
import vpomodel.rest.ReportingRestServices;
import vpomodel.rest.TrailsSummaryRestServices;
import vpomodel.rest.UserManagementRestServices;

@ApplicationPath("resources")
@PolicySet(references = { @PolicyReference(value = "oracle/http_wls_security_service_policy") })
public class GenericApplication extends Application {
    public Set<Class<?>> getClasses() {
        Set<Class<?>> classes = new HashSet<Class<?>>();

        // Register root resources.
        classes.add(TrailsSummaryRestServices.class);
        classes.add(DashboardRestServices.class);
        classes.add(UserManagementRestServices.class);
        classes.add(FormAutomationRestServices.class);
        classes.add(ReportingRestServices.class);
        classes.add(CountryRestServices.class);

        // Register provider classes.

        return classes;
    }
}

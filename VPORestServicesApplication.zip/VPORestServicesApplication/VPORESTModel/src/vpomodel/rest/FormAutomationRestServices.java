package vpomodel.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import oracle.jbo.ApplicationModule;
import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import oracle.jbo.client.Configuration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


@Path("formautomation")
@Consumes("application/json")
@Produces("application/json")
public class FormAutomationRestServices {
    private static final String amDef = "vpomodel.eo.AppModule";
    private static final String config = "AppModuleLocal";

    public FormAutomationRestServices() {
        super();
    }


    @GET
    @Path("/countryCode")
    public String getCountryCode(@QueryParam("personnelIdVal") String personnelId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("CountryCodeLOV1");
                vo.setNamedWhereClauseParam("in_personnel3", personnelId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("countryCodeId", row.getAttribute("Value").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("countryCodeId", "");
                        }
                        try {
                            jsonObjectR3.put("countryCode", row.getAttribute("Value").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("countryCode", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("countryCode", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/siteListForUser")
    public String getSiteListForUser(@QueryParam("personnelIdVal") String personnelId,
                                     @QueryParam("countryIdVal") String countryId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("SiteListForUser1");
                vo.setNamedWhereClauseParam("in_personnel1", personnelId);
                vo.setNamedWhereClauseParam("in_countryCode", countryId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("studysiteid", row.getAttribute("Studysiteid").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studysiteid", "");
                        }
                        try {
                            jsonObjectR3.put("studysite", row.getAttribute("Studysite").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studysite", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("studySiteCode", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/trialsForSite")
    public String getTrialsForSite(@QueryParam("personnelIdVal") String personnelId,
                                   @QueryParam("countryIdVal") String countryId,
                                   @QueryParam("studyIdVal") String studyId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("TrialsForSite1");
                vo.setNamedWhereClauseParam("in_studySite1", studyId);
                vo.setNamedWhereClauseParam("in_personnel2", personnelId);
                vo.setNamedWhereClauseParam("in_countryCode3", countryId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("trialId", row.getAttribute("StudySiteEref").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("trialId", "");
                        }
                        try {
                            jsonObjectR3.put("trialCode", row.getAttribute("StudyCodeAlias").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("trialCode", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("trialCode", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/allVendors")
    public String getAllVendorCategories() {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("AllVendorCategories1");
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("vendorCategoryId", row.getAttribute("VendorCategoryId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorCategoryId", "");
                        }
                        try {
                            jsonObjectR3.put("vendorCategoryName", row.getAttribute("VendorCategoryName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorCategoryName", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("vendorCategory", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/vendorForCategory")
    public String getVendorsForCategory(@QueryParam("categoryIdVal") String categoryId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("VendorsForCategory1");
                vo.setNamedWhereClauseParam("in_vendorCategoryId", categoryId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("vendorId", row.getAttribute("VendorId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorId", "");
                        }
                        try {
                            jsonObjectR3.put("vendorName", row.getAttribute("VendorName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorName", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("vendorCategory", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/formListing")
    public String getFormListing(@QueryParam("personnelIdVal") String personnelId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("FormListingMO2_1");
                vo.setNamedWhereClauseParam("fl_personnelId", personnelId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("formId", row.getAttribute("FormId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formId", "");
                        }
                        try {
                            jsonObjectR3.put("formName", row.getAttribute("FormName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formName", "");
                        }

                        try {
                            jsonObjectR3.put("submissionDueDate", row.getAttribute("SubmissionDueDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("submissionDueDate", "");
                        }
                        try {
                            jsonObjectR3.put("status", row.getAttribute("Status").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("status", "");
                        }
                        try {
                            jsonObjectR3.put("updatedDate", row.getAttribute("UpdatedDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("updatedDate", "");
                        }
                        try {
                            jsonObjectR3.put("vendorCategoryMappingId",
                                             row.getAttribute("VendorCategoryMappingId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorCategoryMappingId", "");
                        }
                        try {
                            jsonObjectR3.put("vendorCategoryId", row.getAttribute("VendorCategoryId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorCategoryId", "");
                        }
                        try {
                            jsonObjectR3.put("vendorCategoryName", row.getAttribute("VendorCategoryName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorCategoryName", "");
                        }

                        try {
                            jsonObjectR3.put("vendorId", row.getAttribute("VendorId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorId", "");
                        }

                        try {
                            jsonObjectR3.put("vendorName", row.getAttribute("VendorName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorName", "");
                        }

                        try {
                            jsonObjectR3.put("studySiteIdVpo", row.getAttribute("StudySiteIdVpo").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studySiteIdVpo", "");
                        }

                        try {
                            jsonObjectR3.put("studyCodeAlias", row.getAttribute("StudyCodeAlias").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studyCodeAlias", "");
                        }

                        try {
                            jsonObjectR3.put("studySiteId", row.getAttribute("StudySiteId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studySiteId", "");
                        }

                        try {
                            jsonObjectR3.put("investigatorName", row.getAttribute("InvestigatorName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("investigatorName", "");
                        }


                        try {
                            jsonObjectR3.put("formFinalizedDate", row.getAttribute("FormFinalizedDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formFinalizedDate", "");
                        }

                        try {
                            jsonObjectR3.put("formVersion", row.getAttribute("FormVersion").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formVersion", "");
                        }

                        try {
                            jsonObjectR3.put("countryCode", row.getAttribute("CountryCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("countryCode", "");
                        }

                        try {
                            jsonObjectR3.put("studySiteEid", row.getAttribute("StudySiteEid").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studySiteEid", "");
                        }

                        try {
                            jsonObjectR3.put("requestReceivedDate", row.getAttribute("RequestReceivedDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("requestReceivedDate", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("countryCode", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/validateForm")
    public String validateFormForUser(@QueryParam("personnelIdVal") String personnelId,
                                      @QueryParam("regionIdVal") String regionId,
                                      @QueryParam("siteIdVal") String siteId,
                                      @QueryParam("studyCodeVal") String trailCode,
                                      @QueryParam("categoryIdVal") String vendorCategoryId,
                                      @QueryParam("vendorIdval") String vendorId,
                                      @QueryParam("statusVal") String status) {
        JSONObject jsonObjectR = new JSONObject();

        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("ValidateFormForUserMO1");
                vo.setNamedWhereClauseParam("validatePersonnelId1", personnelId);
                vo.setNamedWhereClauseParam("validateRegionId1", regionId);
                vo.setNamedWhereClauseParam("validateSiteId1", siteId);
                vo.setNamedWhereClauseParam("validateTrailCode1", trailCode);
                vo.setNamedWhereClauseParam("validateVendorCategoryId1", vendorCategoryId);
                vo.setNamedWhereClauseParam("validateVendorId1", vendorId);
                vo.setNamedWhereClauseParam("validateStatus1", status);
                vo.executeQuery();

                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        try {
                            jsonObjectR.put("formId", row.getAttribute("FormId").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("formId", "0");
                        }

                        try {
                            jsonObjectR.put("vendorCategoryMappingId",
                                            row.getAttribute("VendorCategoryMappingId").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("vendorCategoryMappingId", "");
                        }

                        try {
                            jsonObjectR.put("studySiteIdVpo", row.getAttribute("StudySiteIdVpo").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("studySiteIdVpo", "");
                        }

                        try {
                            jsonObjectR.put("personnelId", row.getAttribute("PersonnelId").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("personnelId", "");
                        }

                        try {
                            jsonObjectR.put("formName", row.getAttribute("FormName").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("formName", "");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/fetchFormData")
    public String fetchFormData(@QueryParam("formIdVal") String formId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("FetchFormData1");
                vo.setNamedWhereClauseParam("fetchFormId", formId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("formId", row.getAttribute("FormId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formId", "");
                        }
                        try {
                            jsonObjectR3.put("formDetails", row.getAttribute("FormDetails").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formDetails", "");
                        }
                        try {
                            jsonObjectR3.put("formDetailsId", row.getAttribute("FormDetailsId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formDetailsId", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("formData", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/formTrialsDetails")
    public String formTrialDetails(@QueryParam("personnelIdVal") String personnelId,
                                   @QueryParam("countryCodeVal") String countryCode,
                                   @QueryParam("siteIdVal") String siteId, @QueryParam("studyCodeVal") String studyCode,
                                   @QueryParam("prefixVal") String prefix) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        if (prefix == null || prefix == "") {
            prefix = "CL";
        }
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("FormTrialsDetails1");
                vo.setNamedWhereClauseParam("trialDetailsCountryCode", countryCode);
                vo.setNamedWhereClauseParam("trialDetailsPersonnelId", personnelId);
                vo.setNamedWhereClauseParam("trialDetailsSiteId", siteId);
                vo.setNamedWhereClauseParam("trialDetailsStudyCode", studyCode);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put(prefix + "SponsorName", "Novartis");
                            //jsonObjectR3.put(prefix + "SponsorName", row.getAttribute("StudySiteEref").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SponsorName", "Novartis");
                        }
                        try {
                            jsonObjectR3.put(prefix + "TrialCode", row.getAttribute("StudyCodeAlias").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "TrialCode", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "SiteId", row.getAttribute("StudySiteId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SiteId", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "ProjectCode", row.getAttribute("ProjectCodeAlias").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "ProjectCode", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("trialDetails", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/formCenter")
    public String formCenter(@QueryParam("stateCodeVal") String stateCode,
                             @QueryParam("countryCodeVal") String countryCode,
                             @QueryParam("studyRefVal") String studyRef, @QueryParam("prefixVal") String prefix) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        if (prefix == null || prefix == "") {
            prefix = "CL";
        }
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("FormCenter1");
                vo.setNamedWhereClauseParam("centerCountryCode", countryCode);
                vo.setNamedWhereClauseParam("centerStateCode", stateCode);
                vo.setNamedWhereClauseParam("centerStudyRef", studyRef);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put(prefix + "ZipCode",
                                             row.getAttribute("PostalAddressPostalCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "ZipCode", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "CenterType", row.getAttribute("CenterTypeDesc").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "CenterType", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "CentreStreetAddress",
                                             row.getAttribute("PostalAddressLines").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "CentreStreetAddress", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "City", row.getAttribute("PostalAddressCityName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "City", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "State", row.getAttribute("PostalAddressStateName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "State", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "Country",
                                             row.getAttribute("PostalAddressCountryName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "Country", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "Department", row.getAttribute("StudySiteEid").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "Department", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("center", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/formInvestigator")
    public String formInvestigator(@QueryParam("regionIdVal") String RegionId,
                                   @QueryParam("countryCodeVal") String countryCode,
                                   @QueryParam("siteIdVal") String siteId, @QueryParam("studyCodeVal") String studyCode,
                                   @QueryParam("prefixVal") String prefix) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        if (prefix == null || prefix == "") {
            prefix = "CL";
        }
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("FormInvestigatorMO1");
                vo.setNamedWhereClauseParam("centerCountryCode", countryCode);
                vo.setNamedWhereClauseParam("centerRegionId", RegionId);
                vo.setNamedWhereClauseParam("centerSiteId", siteId);
                vo.setNamedWhereClauseParam("centerStudyCode", studyCode);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put(prefix + "RoleName", row.getAttribute("RoleAtSiteLvlDesc").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "RoleName", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "roleAtSiteLvlCode", row.getAttribute("RoleAtSiteLvlCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "roleAtSiteLvlCode", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "Title", row.getAttribute("Title").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "Title", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "FirstName", row.getAttribute("Forename").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "FirstName", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "MiddleName", row.getAttribute("MiddleName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "MiddleName", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "LastName", row.getAttribute("Surname").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "LastName", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "PhoneCode", row.getAttribute("PhoneAddress").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "PhoneCode", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "EmailAddress", row.getAttribute("EmailAddress").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "EmailAddress", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "FaxNumber", row.getAttribute("FaxAddress").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "FaxNumber", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressLines", row.getAttribute("PostalAddressLines").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "PostalAddressLines", "");
                        }                        try {
                            jsonObjectR3.put(prefix + "postalAddressStateName", row.getAttribute("PostalAddressStateName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressStateName", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressPostalCode", row.getAttribute("PostalAddressPostalCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressPostalCode", "");
                        }
                        
                        try {
                            jsonObjectR3.put(prefix + "postalAddressCityName", row.getAttribute("PostalAddressCityName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "PostalAddressCityName", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressCountryName", row.getAttribute("PostalAddressCountryName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressCountryName", "");
                        }
                        

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("Investigator", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/secondaryContact")
    public String formSecondaryContact(@QueryParam("regionIdVal") String regionId,
                                       @QueryParam("countryCodeVal") String countryCode,
                                       @QueryParam("siteIdVal") String siteId,
                                       @QueryParam("studyCodeVal") String studyCode,
                                       @QueryParam("prefixVal") String prefix) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        if (prefix == null || prefix == "") {
            prefix = "CL";
        }
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("FormSecondaryContactMO2");
                vo.setNamedWhereClauseParam("secondaryCountryCode", countryCode);
                vo.setNamedWhereClauseParam("secondaryRegionId", regionId);
                vo.setNamedWhereClauseParam("secondarySiteId", siteId);
                vo.setNamedWhereClauseParam("secondaryStudyCode", studyCode);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("roleAtSiteLvlDesc", row.getAttribute("RoleAtSiteLvlDesc").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("roleAtSiteLvlDesc", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "roleAtSiteLvlCode", row.getAttribute("RoleAtSiteLvlCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "roleAtSiteLvlCode", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "SecondatyTitle", row.getAttribute("Title").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SecondatyTitle", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "SecondaryFirstName", row.getAttribute("Forename").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SecondaryFirstName", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "SecondaryMiddleName", row.getAttribute("MiddleName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SecondaryMiddleName", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "SecondaryLastName", row.getAttribute("Surname").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SecondaryLastName", "");
                        }

                        

                        try {
                            jsonObjectR3.put(prefix + "SecondaryPhoneCode",
                                             row.getAttribute("PhoneAddress").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SecondaryPhoneCode", "");
                        }


                        try {
                            jsonObjectR3.put(prefix + "SecondaryFaxNumber", row.getAttribute("FaxAddress").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SecondaryFaxNumber", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "SecondaryEmailAddress",
                                             row.getAttribute("EmailAddress").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SecondaryEmailAddress", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressLines", row.getAttribute("PostalAddressLines").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressLines", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressStateName", row.getAttribute("PostalAddressStateName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressStateName", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressPostalCode", row.getAttribute("PostalAddressPostalCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressPostalCode", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressCityName", row.getAttribute("PostalAddressCityName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressCityName", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressCountryName", row.getAttribute("PostalAddressCountryName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressCountryName", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("secondaryContact", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/getVersionHistory")
    public String formGetVersionHistory(@QueryParam("categoryIdVal") String categoryId,
                                        @QueryParam("countryCodeVal") String countryCode,
                                        @QueryParam("siteIdVal") String siteId,
                                        @QueryParam("studyCodeVal") String studyCode,
                                        @QueryParam("personnelIdVal") String personnelId,
                                        @QueryParam("vendorIdVal") String vendorId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("FormVersionHistory1");
                vo.setNamedWhereClauseParam("historyCategoryId", categoryId);
                vo.setNamedWhereClauseParam("historyCountryCode", countryCode);
                vo.setNamedWhereClauseParam("historyPersonnelId", personnelId);
                vo.setNamedWhereClauseParam("historyStudyCode", studyCode);
                vo.setNamedWhereClauseParam("historyStudySiteId", siteId);
                vo.setNamedWhereClauseParam("historyVendorId", vendorId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("formId", row.getAttribute("FormId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formId", "");
                        }
                        try {
                            jsonObjectR3.put("formVersion", row.getAttribute("FormVersion").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formVersion", "");
                        }

                        try {
                            jsonObjectR3.put("updatedBy", row.getAttribute("UpdatedBy").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("updatedBy", "");
                        }

                        try {
                            jsonObjectR3.put("updatedDate", row.getAttribute("UpdatedDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("updatedDate", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("versionHistory", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }

    @GET
    @Path("/ReleaseLock")
    public String getVendorsReleaseLock(@QueryParam("SiteRefVal") String siteRef,
                                        @QueryParam("VendorCategoryIdVAL") String vendorCategoryId,
                                        @QueryParam("VendorIdVal") String vendorId) 
    {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("ReleaseLock1");
                vo.setNamedWhereClauseParam("siteRef", siteRef);
                vo.setNamedWhereClauseParam("vendorCategoryId", vendorCategoryId);
                vo.setNamedWhereClauseParam("vendorId", vendorId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("formId", row.getAttribute("FormId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formId", "");
                        }
                        


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("vendorCategory", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }
}

package vpomodel.rest;


import java.util.HashMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import oracle.jbo.ApplicationModule;
import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import oracle.jbo.client.Configuration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import vpomodel.eo.AppModuleImpl;


@Path("reporting")
@Consumes("application/json")
@Produces("application/json")
public class ReportingRestServices {

    private static final String amDef = "vpomodel.eo.AppModule";
    private static final String config = "AppModuleLocal";

    public ReportingRestServices() {
        super();
    }


    @GET
    @Path("/reportingItems")
    public String getReportingItems(@QueryParam("questionStatusVal") String questionStatus) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("ReportingItems1");
                vo.setNamedWhereClauseParam("questionStatus1", questionStatus);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("questionCategory", row.getAttribute("QuestionCategory").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("questionCategory", "");
                        }

                        try {
                            jsonObjectR3.put("questionDetails", row.getAttribute("QuestionDetails").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("questionDetails", "");
                        }

                        try {
                            jsonObjectR3.put("questionId", row.getAttribute("QuestionId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("questionId", "");
                        }
                        try {
                            jsonObjectR3.put("questionStatus", row.getAttribute("QuestionStatus").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("questionStatus", "");
                        }
                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        //e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("items", jsonCountryArrayR2);
                } catch (Exception e) {
                    //e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/createReport")
    public String getReportingCreate(@QueryParam("questionIdVal") String questionId,
                                     @QueryParam("phaseNameval") String phaseName,
                                     @QueryParam("regionIdVal") String regionId,
                                     @QueryParam("countryIdVal") String countryId,
                                     @QueryParam("vendorCategoryIdVal") String vendorCategoryId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("ReportingCreateMo1");
                vo.setNamedWhereClauseParam("questionId_MO", questionId);
                vo.setNamedWhereClauseParam("pphaseName_MO", phaseName);
                vo.setNamedWhereClauseParam("regionId_MO", regionId);
                vo.setNamedWhereClauseParam("countryId_MO", countryId);
                vo.setNamedWhereClauseParam("vendorCategoryId_MO", vendorCategoryId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();


                        try {
                            jsonObjectR3.put("phaseName", row.getAttribute("PhaseName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("phaseName", "");
                        }
                        try {
                            jsonObjectR3.put("countryName", row.getAttribute("CountryName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("countryName", "");
                        }

                        try {
                            jsonObjectR3.put("questionDetails", row.getAttribute("QuestionDetails").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("questionDetails", "");
                        }

                        try {
                            jsonObjectR3.put("CENTRAL_LAB", row.getAttribute("VcCentralLab").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("CENTRAL_LAB", "");
                        }
                        try {
                            jsonObjectR3.put("IRT", row.getAttribute("VcIrt").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("IRT", "");
                        }
                        try {
                            jsonObjectR3.put("ECG", row.getAttribute("VcEcg").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("ECG", "");
                        }
                        try {
                            jsonObjectR3.put("comments", row.getAttribute("Comments").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("comments", "");
                        }
                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        //e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("createReport", jsonCountryArrayR2);
                } catch (Exception e) {
                    //e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/vendorForms")
    public String getVendorForms(@QueryParam("fromDateVal") String pFromDate, @QueryParam("toDateVal") String pToDate,
                                 @QueryParam("trialVal") String pTrail, @QueryParam("countryVal") String pCountry,
                                 @QueryParam("siteVal") String pSite,
                                 @QueryParam("primaryInvVal") String pPrimaryInvestigation,
                                 @QueryParam("craVal") String pCra, @QueryParam("vendorCatVal") String pVendorCategory,
                                 @QueryParam("vendorVal") String pVendor,
                                 @QueryParam("draftFormsVal") String pDraftForms,
                                 @QueryParam("totalFormsVal") String pTotalForms,
                                 @QueryParam("completedFormsVal") String pCompletedForms,
                                 @QueryParam("overdueFormsVal") String pOverdueForms) {
        JSONObject jsonObjectR;

        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);

            try {
                AppModuleImpl service = (AppModuleImpl) am;
                //                if (pTrail.equalsIgnoreCase(null) || pTrail.equalsIgnoreCase("")) {
                //                    pTrail = null;
                //                }

                String vendorResults =
                    service.getVendorFormReportProcedure(pFromDate, pToDate, pTrail, pCountry, pSite,
                                                         pPrimaryInvestigation, pCra, pVendorCategory, pVendor,
                                                         pDraftForms, pTotalForms, pCompletedForms, pOverdueForms);
                jsonObjectR = new JSONObject(vendorResults);
                service.remove();
                Configuration.releaseRootApplicationModule(am, true);
            } catch (Exception e) {
                e.printStackTrace();
                jsonObjectR = new JSONObject();
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
            }

        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


}
